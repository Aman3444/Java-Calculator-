/**
 * File Name:       CalculatorViewController.java
 * Author:          Multani Aman, 040877727
 * Course:          CST8221 - JAP, 301
 * Assignment:      1 Part 1
 * Date:            2 March 2018
 * Professor:       Svillen Ranev
 * Purpose:         class build the GUI of the calculator  
 * Class list:      CalculatorViewController, Controller
 *                  
 */
package calculator;

/*All the import statements*/
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.Box;
import java.awt.Font;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 * Class which builds the GUI of a Calculator
 * @author Aman Multani
 * @version 1.0
 * @see Calculator
 * @since 1.8.0_102
 */
public class CalculatorViewController extends JPanel{
           
     private JTextField display1; // the calculator display1 field reference   
     private JTextField display2; // the calculator display2 field reference
     private JLabel error; // the mode/error display label reference 
     private JButton dotButton; // the decimal point (dot) button reference 
    
     /*array which stores the number and the operation */
      public static final String[] NumberPad = {"7", "8","9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "0", ".","\u00B1","+" };
     /*reference for action event*/
      private final ActionListener controller;
    
    /**
     * Default constructor which builds GUI of a calculator.
     * @param N/A
     */
    public CalculatorViewController(){

        /*refernce to the Controller for handling th eevnts */
        controller = new Controller();
        /*setting the layout for the whole panel*/
        setLayout(new BorderLayout());
        /*sets the black border*/
        setBorder(BorderFactory.createMatteBorder(5, 5, 5, 5, Color.BLACK));
    
        /*setting the text panel layout and its border*/
        JPanel displayPanel= new JPanel();
        displayPanel.setLayout(new GridLayout(2,0));
        displayPanel.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 1, Color.BLACK));
        
        /*setting the buttonpanel , its layout and the border */
        JPanel KeyButton = new JPanel();
        KeyButton.setLayout(new GridLayout(4,4,3,3));
        KeyButton.setBorder(BorderFactory.createEmptyBorder(3,2,3,2 ));   
             
       /*A loop for the placement of the buttons in the number panel*/
        for(int i=0;i<NumberPad.length;i++){
           if(NumberPad[i].equals("\u00B1")){
           KeyButton.add(createButton("\u00B1","\u00B1",Color.BLACK,Color.PINK, new Controller()));  
            }else if (NumberPad[i].equals(".")){
                  KeyButton.add(createButton(NumberPad[i],NumberPad[i],Color.BLACK,Color.BLUE,new Controller()));   
            }else if (NumberPad[i].equals("-")||NumberPad[i].equals("+")||NumberPad[i].equals("/")||NumberPad[i].equals("*")){
                  KeyButton.add(createButton(NumberPad[i],NumberPad[i],Color.BLACK,Color.CYAN,new Controller()));     
            }else{
                  KeyButton.add(createButton(NumberPad[i],NumberPad[i],Color.BLACK,Color.BLUE,new Controller()));  
            }   
        }
         
        
        /*creating a new button for the clear "C"*/    
        JPanel clear = new JPanel(); 
        /*assigning the size*/
        clear.setLayout(new GridLayout(1,1,1,1));
        /*Creating a new Button for equal "="*/
        JPanel equal = new JPanel();
        /*assigning the size*/
        equal.setLayout(new GridLayout(1,1,1,1));
    
        clear.add(createButton("C", "C", Color.BLACK, Color.RED, controller )); 
        equal.add(createButton("=", "=", Color.BLACK, Color.MAGENTA, controller)); 

        /*creating a button and setting a text value to it */
        JRadioButton SinglePreciButton = new JRadioButton(".0", false);
        /*Setting the background color and the actionlistener to it */
        SinglePreciButton.setBackground(Color.YELLOW);
        SinglePreciButton.addActionListener(controller);
       
        /*creating a button and setting a default text value to it */
        JRadioButton DoublePreciButton = new JRadioButton(".00", true);
        /*Setting the background color and the actionlistener to it */
        DoublePreciButton.setBackground(Color.YELLOW);
        DoublePreciButton.addActionListener(controller);
         
        /*creating a button and setting a text value to it */
        JRadioButton SciButton = new JRadioButton("Sci");
        /*Setting the background color and the actionlistener to it */
        SciButton.setBackground(Color.YELLOW);
        SciButton.addActionListener(controller);
         
        /*creating a panel for 3 radio button together */
        JPanel RadioBotton = new JPanel();
        /*setting the layout for button*/
        RadioBotton.setLayout(new GridLayout(1, 0, 1,0));
        /*Adding all toghter at once*/
	RadioBotton.add(SinglePreciButton);
	RadioBotton.add(DoublePreciButton);
	RadioBotton.add(SciButton);

        /*creating the checkbox with the text value*/
        JCheckBox CheckBoxMode = new JCheckBox("int");
        /*Setting the background color and the actionlistener to it */
        CheckBoxMode.setBackground(Color.GREEN);
        CheckBoxMode.addActionListener(controller);
        CheckBoxMode.setLayout (new BorderLayout());
        
        /*creaking a horizontal box to handle the checkbox and all the radio buttons*/
        Box boxCheck = Box.createHorizontalBox();
        boxCheck.setBackground(Color.BLACK);
        boxCheck.add(CheckBoxMode);
        /*to set the alignment in the container*/
        boxCheck.add(Box.createHorizontalStrut(127));
        boxCheck.add(SinglePreciButton);
        boxCheck.add(DoublePreciButton);
        boxCheck.add(SciButton);
        
        /*creating a buttonGroup for grouping the Checkbox and radiobuttons*/
        ButtonGroup PreciButtonGroup = new ButtonGroup();
        /*including the check box and buttons in the ButtonGroup*/
        PreciButtonGroup.add(CheckBoxMode);
        PreciButtonGroup.add(SinglePreciButton);
        PreciButtonGroup.add(DoublePreciButton);
        PreciButtonGroup.add(SciButton);
        
        display1 = new JTextField();
        /*TextFeild with 16 coloums and 30 height*/
        display1.setPreferredSize(new Dimension(16, 30)); 
        /*Background set to white*/
        display1.setBackground(Color.WHITE); 
        /*cannot be editable*/
	display1.setEditable(false);  
	/*Aligned to the right side*/
        display1.setHorizontalAlignment(JTextField.RIGHT);  
        /*set no border*/
        display1.setBorder(null); 
      
        display2= new JTextField();
        /*TextFeild with 16 coloums and 30 height*/
        display2.setPreferredSize(new Dimension(16, 30)); 
        /*Background set to white*/
        display2.setBackground(Color.WHITE); 
        /*cannot be editable*/
	display2.setEditable(false);  
	/*Aligned to the right side*/
        display2.setHorizontalAlignment(JTextField.RIGHT);
        /*displays 0.0 when GUI is made visible for the first time */
        display2.setText("0.0"); 
        /*set no border*/
        display2.setBorder(null); 

        /*adding the display1 and diaplay2 into the main panel displaypanel*/
        displayPanel.add(display1);
        displayPanel.add(display2);
         
        /*creating a new lable for the mode/error*/
        error = new JLabel("F");
        /*setting up the dimensions*/
        error.setPreferredSize(new Dimension(35,55));
        /*making the button transparent*/
        error.setOpaque(true);
        /*backgroung color*/
        error.setBackground(Color.YELLOW);
        /*seting up the border line 1 for left and right*/
        error.setBorder(BorderFactory.createMatteBorder(0,1,0,1, Color.BLACK));
        /*setting the font size and font to the bold */
        error.setFont(new Font(error.getFont().getName(), Font.BOLD, 25));
        /*the text "F" in horizontal and in center */
        error.setHorizontalAlignment(JLabel.CENTER);
  
        /*creating a JButton for the backspace */
        JButton backspaceButton = new JButton("\u21E6");        
        /*setting up the dimensions*/
        backspaceButton.setPreferredSize(new Dimension(35, 55)); 
        /*making the button transparent*/
        backspaceButton.setOpaque(true);
        /*backgroung color*/
        backspaceButton.setBackground(Color.YELLOW); 
        /*seting up the border line 1 for left and right*/
        backspaceButton.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 1, Color.BLACK));
        /*the tool tip*/
        backspaceButton.setToolTipText("Backspace(Alt-B)"); 
        /*setting the font size and font to the bold */
        backspaceButton.setFont(new Font(backspaceButton.getFont().getName(), Font.BOLD, 25));
        /*reaction will take place with "Alt-B" key*/
        backspaceButton.setMnemonic('B');
        /*text to display on click*/
        backspaceButton.setActionCommand("backspace");
        backspaceButton.addActionListener(controller);
        
        /*a panel containig the error/mode lable,  backspace , textfiled , checkbox and the radio buttons*/
        JPanel northPanel= new JPanel();
        /*setting up the borderlayout*/
        northPanel.setLayout(new BorderLayout());
        /*adding the button into the panel "F" , "backspace button" and the display panel with position*/
        northPanel.add(error,BorderLayout.WEST);
        northPanel.add(displayPanel,BorderLayout.CENTER);
        northPanel.add(backspaceButton,BorderLayout.EAST);
               
        /*creatingbthe temp panel for the adding purpose of the clear panel*/
        JPanel ClearPanel= new JPanel();
        /*setting the borderlayout*/
        ClearPanel.setLayout(new BorderLayout()); 
        
        /*setting the panel for check box and radio button*/
        JPanel ModePanel = new JPanel();
        ModePanel.setLayout(new BorderLayout());
        
        ModePanel.setBackground(Color.BLACK);
        ModePanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
        /*adding the Boxcheck componenet into panel*/ 
        ModePanel.add(boxCheck);
        /*adding the modepanel into north panel */
        northPanel.add(ModePanel, BorderLayout.SOUTH);
        /*adding the north panel into the temporary panel named clearpanel*/
        ClearPanel.add(northPanel,BorderLayout.NORTH);
        /*adding the clear button into clearpanel for display*/
        ClearPanel.add(clear);
        
        /*adding the clearpanel into the whole panel*/
        add(ClearPanel,BorderLayout.NORTH);
        /*adding the keyButtons in the whole panel */
        add(KeyButton,BorderLayout.CENTER);
        /*adding the equal panel into the whole panel*/
        add(equal,BorderLayout.SOUTH);
}
   
    /**
     * A method for creating JButton and group of relative buttons.
     * @param text-the textlable button
     * @param ac - buttons action string.
     * @param fg - color for foreground button).
     * @param bg - color of the background.
     * @param handler - ActionListener button.
     * @return - reference to the button .
     */
   
   private JButton  createButton(String text, String ac, Color fg, Color bg, ActionListener handler){
       
   JButton button = new JButton(); //create a new button
   /**set new button properties**/
   button.setText(text);	
   button.setForeground(fg);
   button.setBackground(bg);
   /*if ac is bull then assign the actioncommand*/
   if (ac == null){
       button.setActionCommand(ac);
	}
   /*properties for the button font*/
   button.setFont(button.getFont().deriveFont(20F));
   /*setting the handler to an action event for the button*/
   button.addActionListener(handler);
   /*return a reference to the button*/
   return button;
   } 
 
         /**
         * Inner class of the claculatorViewContoller.
	 *  
	 * @author Aman Multani
	 * @version 1
	 * @see calculator
	 * @since 1.8.0_102 
	 *
	 */
 private class Controller implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			display2.setText(event.getActionCommand());
		}
	}       
}