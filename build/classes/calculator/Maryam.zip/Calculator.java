package calculator;

/* File name:   Calculator.java
 * Author:      Maryum Awan
 * Course:      CST8221 - JAP, Lab Section: 301
 * Assignment:  1, Part 1
 * Date:        March 2, 2018
 * Professor:   Svillen Ranev
 * Purpose:     It  will displays the splash screen first and then it will launches 
 *              the actual calculator application
 */

import java.awt.Dimension;
import java.awt.EventQueue;
import javax.swing.JFrame;
/*
 * This class is the launcher for this calculator application. 
 * @author  Maryum Awan
 * @version 1.0
 * @see     calculator
 * @since   1.8.0_162
 */
public class Calculator {	
	/*
	 * First creates a splash screen for a certain duration, and then creates the {@link CalculatorView}.
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		// The duration of the splash screen is in milliseconds
		long splashScreenDuration = 5000; 
                		
		// Displays the splash screen
		(new CalculatorSplashScreen((int) splashScreenDuration)).showSplashWindow();
		
		/*
                 * The EventQueue.invokeLater method runs main calculator application
                 * @param new Runnable - to run the frame
		 */
                EventQueue.invokeLater(new Runnable() {
			/**
			 * This is the run method to run the frame
			 * @param N/A
			 */
			public void run() {
                                // It will display the Calculator writte on the frame
				JFrame frame = new JFrame("Calculator");
                                // set width and height of the frame
				frame.setMinimumSize(new Dimension(320, 520));
				// It will exit the application
                                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				// Sets the contentPane property
                                frame.setContentPane(new CalculatorViewController());
				frame.setLocationByPlatform(true);	
				// Display the window
                                frame.setVisible(true);
			}
		});
	} // end main
} // end class Calculator