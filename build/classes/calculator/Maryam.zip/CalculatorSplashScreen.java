package calculator;

/* File name:   CalculatorSplashScreen.java
 * Author:      Maryum Awan
 * Course:      CST8221 - JAP, Lab Section: 301
 * Assignment:  1, Part 1
 * Date:        March 2, 2018
 * Professor:   Svillen Ranev
 * Purpose:     This class displays the splash screen for this calculator 
 *              before launching the application
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JWindow; 
import javax.swing.border.EmptyBorder;
import javax.swing.JProgressBar;

/**
 * This class is responsible for displaying a splash screen before the launch of the application
 * @author  Maryum Awan
 * @version 1.0
 * @see     calculator
 * @since   1.8.0_162
 */
public class CalculatorSplashScreen extends JWindow{
	
        // Swing components are serialize and require serialVersionUID 
         private static final long serialVersionUID = 6248477390124803341L;
        // Splash screen duration 
         private final int duration;
         // min progressBar
         private static final int Min = 0; 
         // max progresBar
         private static final int Max = 100; 
	 private JProgressBar progressBar;
	/**
	 * This default constructor to set the show time of the splash screen.
	 * @param duration 
	 */
	public CalculatorSplashScreen(int duration) {
		this.duration = duration;
	}
	
	/**
	 * The method is responsible for showing a splash screen in the center of
	 * the desktop for the amount of time given in the constructor. 
	 * @param N/A 
	 */
	public void showSplashWindow() {
		// To build the content panel
		JPanel content = new JPanel(new BorderLayout()); 
		// to set the background color 
                content.setBackground(Color.WHITE);
                
                /*Progress Bar*/
                // creates the progress bar
		progressBar = new JProgressBar(); 
		progressBar.setMinimum(Min);
		progressBar.setMaximum(Max);
		progressBar.setString("Loading Calculator, Please wait..");
                // set the string on the bar
		progressBar.setStringPainted(true); 
                // set the color to red
                progressBar.setForeground(Color.PINK);
                
                
		// Set the window's bounds, position the window in the center of the screen 
		int width = 500 + 10;
		int height = 255 + 10;
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screen.width - width) / 2;
		int y = (screen.height - height) / 2;
		
                // Set the location and the size of the window
                setBounds(x, y, width, height);
                
                // Create the splash screen
		JLabel label = new JLabel(new ImageIcon(getClass().getResource("giphy.gif")));
		label.setBorder(new EmptyBorder(10,0,10,0));
                
                // To build the name and student number label.
                JLabel demo = new JLabel("Maryum Awan " + "040-854-923", JLabel.CENTER);
                // to set the font for the name and the student number
		content.add(label, BorderLayout.CENTER);
		demo.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 14));
                content.add(label, BorderLayout.CENTER);
                content.add(demo, BorderLayout.SOUTH);
                // create custom RGB color
                Color customColor = new Color(44, 197, 211);
                content.setBorder(BorderFactory.createLineBorder(customColor, 10));
                content.add(demo, BorderLayout.SOUTH);
                // adds progress bar to the contents
                content.add(progressBar, BorderLayout.NORTH); 
                // to createLineBorder
	        content.setBorder(BorderFactory.createLineBorder(customColor, 12));
                //replace the window content pane with the content JPanel
                setContentPane(content);	
                // make the splash window visible
		setVisible(true);  
		
                // loop for the progress in the bar
		for (int i = Min; i <= Max; i++) { 
			final int percent=i;
			try {
				progressBar.setValue(percent);
				java.lang.Thread.sleep(50);
			} catch (InterruptedException e) {
                            System.out.print("");
                        }
} // end for loop 
		 // destroy the window and release all resources 
                dispose();              	
	} // end of showSplashWindow
} // end of CalculatorSplashScreen class