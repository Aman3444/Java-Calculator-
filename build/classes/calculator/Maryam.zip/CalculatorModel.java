/* File name:   CalculatorViewController.java
 * Author:      Maryum Awan
 * Course:      CST8221 - JAP, Lab Section: 301
 * Assignment:  1, Part 1
 * Date:        March 2, 2018
 * Professor:   Svillen Ranev
 * Purpose:     This class  is responsible for building the calculator GUI
 * Class list:  CalculatorViewController
 *              Controller
 */
package calculator;

/**
 *
 * @author dell
 *
 * */

public class CalculatorModel { // This function will calculate the result for two operands and one operation.
    private String op1 = "";
    private String op2 = "";
    private String opcode = "";
    private String mode = "F";
    private String precision = ".00";
    private String result = "";
    private boolean errorState = false;
    
    private void calculate(){
        if(!op1.isEmpty() && op2.isEmpty()){
            result = op1;
            return;
        }
        if("F".equals(mode)){ // IF mode is float
            double tempResult = 0;
            try{
                if("+".equals(opcode)){
                    tempResult = Double.parseDouble(op1) + Double.parseDouble(op2) ;
                }
                else if("-".equals(opcode)){
                    tempResult = Double.parseDouble(op1) - Double.parseDouble(op2) ;
                }
                else if("*".equals(opcode)){
                    tempResult = Double.parseDouble(op1) * Double.parseDouble(op2) ;
                }
                else if("/".equals(opcode)){
                    if(op2.equals( "0" )){
                        result = "Cannot divide by zero";
                        errorState = true;
                        return;
                    }
                    tempResult = Double.parseDouble(op1) / Double.parseDouble(op2) ;
                }
                
                if(".0".equals(precision))
                    result = String.format("%.1f", tempResult); // Storing result according to the precision
                else if(".00".equals(precision))
                    result = String.format("%.2f", tempResult); // Storing result according to the precision
                else if("Sci".equals(precision))
                    result = String.format("%.6E", tempResult); // Storing result according to the precision
                
                  
            }
            catch(Exception e){
                result = "Result undefined"; // If anything invalid is entered
                errorState = true; // setting error state to true
            }
        }
        
        if("I".equals(mode)){ // Integer mode
            try{
                if("+".equals(opcode)){
                   result = Integer.toString(Integer.parseInt(op1)+Integer.parseInt(op2)) ;
                }
                else if("-".equals(opcode)){
                    result = Integer.toString(Integer.parseInt(op1)-Integer.parseInt(op2)) ;
                }
                else if("*".equals(opcode)){
                    result = Integer.toString(Integer.parseInt(op1)*Integer.parseInt(op2)) ;
                }
                else if("/".equals(opcode)){
                    if(op2.equals( "0" )){
                        result = "Cannot divide by zero";
                        errorState = true;
                        return;
                    }
                    result = Integer.toString(Integer.parseInt(op1)/Integer.parseInt(op2)) ;
                }
            }
            catch(Exception e){
                result = "Result undefined"; // If anything invalid is entered
                errorState = true; // setting error state to true
            }
        }
    }
    
    public void setOpcode(String op){
        opcode = op;
    }
    
    public String getOpcode(){
        return opcode;
    }
    
    public void setOp1(String op){
        op1 = op;
    }
    
    public String getOp1(){
        return op1;
    }
    
    public void setOp2(String op){
        op2 = op;
    }
    
    public String getOp2(){
        return op2;
    }
    
    public void setMode(String s_mode){
        mode = s_mode;
    }
    
    public String getMode(){
        return mode;
    }
    
    public void setPrecision(String s_precision){
        precision = s_precision;
    }
    
    public String getPrecision(){
        return precision;
    }
    
    public boolean getErrorstate(){
        return errorState;
    }
    
    public String getResult(){
        calculate(); // This will store final output in result string.
        return result;
    }
    
    public void reset(){ // Reset the calculator. Delete everything that was entered before
        op1 = "";
        op2 = "";
        opcode = "";
        mode = "F";
        precision = ".00";
        result = "";
        errorState = false;
       
    }
    
}