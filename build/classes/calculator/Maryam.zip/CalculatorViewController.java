package calculator;

/* File name:   CalculatorViewController.java
 * Author:      Maryum Awan
 * Course:      CST8221 - JAP, Lab Section: 301
 * Assignment:  1, Part 1
 * Date:        March 2, 2018
 * Professor:   Svillen Ranev
 * Purpose:     This class  is responsible for building the calculator GUI
 * Class list:  CalculatorViewController
 *              Controller
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/*
 * This class builds the calculators GUI.
 * @author  Maryum Awan
 * @version 1.0
 * @see     calculator
 * @since   1.8.0_162
 */
public class CalculatorViewController extends JPanel {
	// the calculator display1 field reference 
        private JTextField display1; 
        // the calculator display2 field reference 
        private JTextField display2;
        // the mode/error display label reference 
        private JLabel error;     
        //the decimal point (dot) button reference 
        private JButton dotButton; 
 
         // {@value} - Backspace button mnemonic 
	private static final char BB_MNEMONIC = 'B';
	// {@value} - Tenths radio button  
	private static final String TR_TEXT_AC = ".0";
	// {@value} - hundredth radio button
	private static final String HR_TEXT_AC = ".00";
	// {@value} - Scientific radio button
	private static final String SR_TEXT_AC = "Sci";
       
	// {@value} nums array that store the numbers and operators
	private static final String[] nums = { "7", "8", "9", "/",
                                               "4", "5", "6", "*", 
                                               "1", "2", "3", "-", 
                                               "0", ".", "\u00B1", "+" };
    
        /*
	 * This is a default constructor which create the GUI of calculator.
	 * @param N/A
	 */
	public CalculatorViewController() {
                CalculatorModel model = new CalculatorModel();
		// Event handler
		Controller controller = new Controller(model);
		// To build the panel for the error label, the display, and the backspace button.
		JPanel errorPanel = new JPanel();    
		// To build the panel for displaying the textField
		JPanel display = new JPanel();   
		// backspace button 
		JButton backspace = new JButton();  
		// Panel for the whole checkBox
		JPanel modePanel = new JPanel();   
                // to build the panel for three radioButtons 
		JPanel radiobutton = new JPanel();             
		// to manage the checkbox and radiostation, created a horizontal box
		Box box = Box.createHorizontalBox();   
		// to group checkBox and radioButtons together 
		ButtonGroup group = new ButtonGroup(); 
		// set the chechBox
		JCheckBox checkBox = new JCheckBox("Int");  
		// set the text of radioButton
		JRadioButton singleJRadioButton = new JRadioButton(TR_TEXT_AC, false); 
		// .00 is selected by default at launch 
		JRadioButton doubleJRadioButton = new JRadioButton(HR_TEXT_AC , true); 
		// set the text of Sci radioButton is not selected 
		JRadioButton sciJRadioButton = new JRadioButton(SR_TEXT_AC, false);
		// for whole keypad panel and operators, created the mainPanel
		JPanel mainPanel = new JPanel();      
		// to create the keypad for displaying numbers and operators
		JPanel keypad = new JPanel();   
		// to build the panel for "C" and "=" buttons 
		JPanel operator = new JPanel();      
		
		// for whole panel set the borderLayout
		setLayout(new BorderLayout());  
		// set the black border for the whole panel
		setBorder(BorderFactory.createMatteBorder(5, 5, 5, 5, Color.BLACK));  
		// define the layout
		errorPanel.setLayout(new BorderLayout()); 
		       
		// To set up the error label 
		error = new JLabel("F");
		// The mode/error display label must have a dimension (35,55)
		error.setPreferredSize(new Dimension(35, 55));  
		// set the button be transparent 
		error.setOpaque(true); 
		// mode/error must be yellow at launch
		error.setBackground(Color.YELLOW);  
		// must have a black left/right black matte border with thickness 1
		error.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));  
		// display the letter F in the middle of the label
		error.setHorizontalAlignment(JLabel.CENTER); 
		// set the font and style for the error label 
		error.setFont(new Font(error.getFont().getName(), error.getFont().getStyle(), 20));

		// To set up and display two textFields
		display.setLayout(new GridLayout(2, 0));  
                // set border with matte black color
		display.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
		display1 = new JTextField();
		// set dimensions to 16 columns and height of 30.
		display1.setPreferredSize(new Dimension(16, 30)); 
                // set background color to white
		display1.setBackground(Color.WHITE); 
		display1.setEditable(false);  
		display1.setHorizontalAlignment(JTextField.RIGHT);  
		// to set an empty border that make up no space between two dimensions
		display1.setBorder(BorderFactory.createEmptyBorder()); 
		
		display2 = new JTextField();
                // set dimensions to 15 columns and the height of 30
		display2.setPreferredSize(new Dimension(15, 30)); 
		// set background color to white
                display2.setBackground(Color.WHITE);
		display2.setEditable(false);
		display2.setHorizontalAlignment(JTextField.RIGHT);
		// display "0.0" at the default
		display2.setText("0.0");
                // to set an empty border that makes up no space between two dimensions
		display2.setBorder(BorderFactory.createEmptyBorder()); 

		// The backspace button must have a dimension (35,55) 
		backspace.setPreferredSize(new Dimension(35, 55));
                // backspace button must be yellow
		backspace.setBackground(Color.YELLOW);
		//backspace.setOpaque(true); 
                // backspace button  must be transparent with a black left/right black matte border with thickness 1
		backspace.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
		// Unicode text for the backspace
		backspace.setText("\u21E6"); 
                // set the font for the backspace
		backspace.setFont(new Font(backspace.getFont().getName(), Font.BOLD, 20));
		// set to add the tool tip 
		backspace.setToolTipText("Backspace (ALT-B)");
		// react with Backspace button
		backspace.setMnemonic(BB_MNEMONIC); 
                // when backspace button is clicked "Backspace" is written on the screen
		backspace.setActionCommand("Backspace");
		backspace.addActionListener(controller);
		
		// add display1 into the display panel
		display.add(display1);  
                // add display2 into the display panel
		display.add(display2);  
		
		// To add the components
		errorPanel.add(error, BorderLayout.WEST);
		errorPanel.add(display, BorderLayout.CENTER);
		errorPanel.add(backspace, BorderLayout.EAST);

		// to set up the checkBox and radioButtons
		modePanel.setLayout(new FlowLayout());
                // background color is black
		modePanel.setBackground(Color.BLACK);
		// panel surrounded by a black matte border with the following insets (5, 5, 5, 5)
                modePanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		// set the background color for chechBox and radioButtons 
		checkBox.setBackground(Color.GREEN);
		checkBox.addActionListener(controller);
		singleJRadioButton.setBackground(Color.YELLOW);
		singleJRadioButton.addActionListener(controller);
		doubleJRadioButton.setBackground(Color.YELLOW);
		doubleJRadioButton.addActionListener(controller);
		sciJRadioButton.setBackground(Color.YELLOW);
		sciJRadioButton.addActionListener(controller);

		/** add the radioButtons together */
		radiobutton.setLayout(new GridLayout(1, 0, 1, 0));  
		radiobutton.add(singleJRadioButton);
		radiobutton.add(doubleJRadioButton);
		radiobutton.add(sciJRadioButton);

		// To set up the box and add the components into a whole box 
		box.setBackground(Color.BLACK);
		box.add(checkBox);
                
		// to struct the align properly the components in the box container 
		box.add(Box.createHorizontalStrut(130)); 
		box.add(singleJRadioButton);
		box.add(doubleJRadioButton);
		box.add(sciJRadioButton);

		// checkBox and the radioButtons included in a button group 
		group.add(checkBox);
		group.add(singleJRadioButton);
		group.add(doubleJRadioButton);
		group.add(sciJRadioButton);

		// add box component into boxPanel 
		modePanel.add(box); 
		// to add the boxPanel into north panel at the South position 
		errorPanel.add(modePanel, BorderLayout.SOUTH); 

		// To set up the numeric keypad buttons 
		mainPanel.setLayout(new BorderLayout());  	
		// set the layout for keypad buttons with same size and set the gaps 
		keypad.setLayout(new GridLayout(4, 4, 3, 3)); 
		// to set the border for the panel 
		keypad.setBorder(BorderFactory.createEmptyBorder(3, 2, 3, 2)); 

            // a for loop to create all of the numeric and arithmetic operation buttons, add them to the calculator keypad panel
            for (String num : nums) {
                switch (num) {
                    // create dotbotton in black color with blue bgcolor 
                    case ".":
                        dotButton = createButton(".",".", Color.BLACK, Color.BLUE, new Controller(model));
                        // dot button added in the keypad
                        keypad.add(dotButton);
                        break;
                    // ± created in black color with Pink bgcolor 
                    case "\u00B1":
                        keypad.add(createButton("\u00B1", "\u00B1", Color.BLACK, Color.PINK, new Controller(model)));
                        break;
                    case "+":
                    case "-":
                    case "*":
                    case "/":
                        // +, -, * and / added to the keypad
                        keypad.add(createButton(num, num, Color.BLACK, Color.CYAN, new Controller(model)));
                        break;
                    default:
                        keypad.add(createButton(num, num, Color.BLACK, Color.BLUE, new Controller(model)));
                        break;
                } // end of switch
            } // end of for loop	
                                // Button above keypad (C)
				JButton clearButtonTop  = createButton("C", "C", Color.BLACK, Color.RED, new Controller(model));
				JPanel clearEqualsPanel = new JPanel(new GridLayout(1, 2, 3, 0));
				clearEqualsPanel.add(clearButtonTop);
	
                                // Button below keypad (=)
				JButton equalsButtonBottom = createButton("=", "=", Color.BLACK, Color.MAGENTA, new Controller(model));
				JPanel equalsClearPanel = new JPanel(new GridLayout(1, 2, 3, 0));
				equalsClearPanel.add(equalsButtonBottom);
                                
	                // Create the panel and layout for the keypad 
			JPanel keypadClrEqPanels = new JPanel(new BorderLayout(0, 2));
			// Create the top clear equals buttons and the bottom equals clear buttons 
			keypadClrEqPanels.add(clearEqualsPanel, BorderLayout.NORTH);
			keypadClrEqPanels.add(keypad, BorderLayout.CENTER);
			keypadClrEqPanels.add(equalsClearPanel, BorderLayout.SOUTH);
		
		        // Add all panels.
			add(errorPanel, BorderLayout.NORTH);
			add(keypadClrEqPanels, BorderLayout.CENTER); 
	} // end of CalculatorViewController

	/*
	 * The method is responsible for the creation of group of related buttons with the same basic properties 
	 * @param text     Creates a new button with a specified text label;
         * @param ac       action command string for the button.
	 * @param fg       Foreground color of the button.
	 * @param bg       Background color of the button.
	 * @param handler  An event handler for this button.
	 * @return         Returns a reference to the created button
	 */
	private JButton createButton(String text, String ac, Color fg, Color bg, ActionListener handler){
		// creating a new button with a label
                JButton button = new JButton(text);
		
		// Setting button action command
		if(ac != null){
			button.setActionCommand(ac);
		}		
		// Setting Foreground color of the button
		button.setForeground(fg);
                // Setting Background color of the button
		button.setBackground(bg);
		
		// Setting button font
		Font defaultFont = button.getFont();
		button.setFont(new Font(defaultFont.getName(), defaultFont.getStyle(), 21));
		
		// Register action listener
		button.addActionListener(handler);
		// returning the button created
		return button;
	} // end of created Button
        
	/*
	 * Event handler for all events that the {@link CalculatorView} generates.
	 * @author  Maryum Awan
	 * @version 1.0
	 * @see     ActionListener
	 * @since   1.8.0_162
	 */
        
        	/**
	 * To display the textField and show other features 
	 * based on the number on floating point or integer mode
	 * 
	 * @param enable - true or false when choose integer or float mode 
	 */
	public void changeMode(boolean isDouble) {
		/** If user clicked the floating point mode */
                dotButton.setEnabled(isDouble);
		if (isDouble) {
                    dotButton.setBackground(Color.BLUE);
                    error.setText("F");
                    error.setBackground(Color.YELLOW);
		} 
                else {
                    dotButton.setBackground(new Color(178, 156, 250));
                    error.setText("I");
                    error.setBackground(Color.GREEN);
		}
	}
        
        private void showErr(){
            error.setText("E");
            error.setBackground(Color.RED);
        } 
        
	private class Controller implements ActionListener {	
		/*
                 * This class is responsible for handling all the events generated by the GUI
                 * @param ActionEvent e - to display the textField text when it gets the action    
                 */
                boolean flag = false;
                CalculatorModel model;
                public Controller(CalculatorModel model) {
                    this.model = model;
                }
		@Override public void actionPerformed(ActionEvent e) {
                    String command  = e.getActionCommand();
                    if(!command.equals("=")){
                        flag = false;
                    }
                    if(command.length()!=0){
                        switch(command){
                            case "0":
                            case "1":
                            case "2":
                            case "3":
                            case "4":
                            case "5":
                            case "6":
                            case "7":
                            case "8":
                            case "9":
                            case ".": //Append numbers and set them in model
                                if(!model.getErrorstate()){
                                    if(model.getOpcode().equals("")){
                                        if(!model.getOp1().equals("") || !command.equals("0") ){
                                            if(!command.equals(".") || !model.getOp1().contains(".")){
                                                display2.setText(model.getOp1() + command);
                                                model.setOp1(model.getOp1() + command);    
                                                System.out.println(model.getOp1());
                                            }
                                        }
                                    }
                                    else{
                                        if(!command.equals(".") || !model.getOp2().contains(".")){
                                                display2.setText(model.getOp2() + command);
                                                model.setOp2(model.getOp2() + command);    
                                        }
                                    }
                                }
                                break;
                            case "+":
                            case "-":
                            case "*":
                            case "/": 
                                if(!model.getErrorstate()){
                                    /* To differentiate - and + as an operator or prefix of a number   */
                                    if(command.equals("*") || command.equals("/")){
                                        display2.setText(model.getOp1());
                                        display1.setText(model.getOp1()  + " " + command);
                                        model.setOpcode(command);
                                        model.setOp2("");
                                    }
                                    else if(model.getOp1().length() != 0 ){ 
                                        if(model.getOpcode().length() == 0){ /* Operator for this case */
                                            display2.setText(model.getOp1());
                                            display1.setText(model.getOp1()  + " " + command);
                                            model.setOpcode(command);
                                            model.setOp2("");
                                        }
                                        else{ /* Prefix for this case */
                                            display2.setText(model.getOp2() + command);
                                            model.setOp2(model.getOp2() + command);
                                            display1.setText(model.getOp1()  + " " + model.getOpcode());
                                        }
                                    }
                                    else{ /* Prefix for this case */
                                        display2.setText(model.getOp1() + command );
                                        model.setOp1(model.getOp1() + command);    
                                        System.out.println(model.getOpcode());
                                    }
                                    
                                }
                                break;
                                
                            case "=": // Compute the result by calling getResult() function of model
                                if(!model.getErrorstate()){
                                    if(model.getOp2().equals("")){
                                        flag = true;
                                        model.setOp2(model.getOp1());
                                    }
                                    display2.setText(model.getResult());
                                    model.setOp1(model.getResult());
                                    if(model.getErrorstate())showErr();
                                    if(!flag){
                                        model.setOp2("");
                                        model.setOpcode("");
                                    }
                                }
                                break;
                                
                            case "Int": // Disable the dot button and change the mode
                                display1.setText("");
                                display2.setText("0");
                                model.reset();
                                if(model.getMode().equals("I")){
                                    model.setMode("F");
                                    changeMode(true);
                                }
                                else{
                                    model.setMode("I");
                                    changeMode(false);
                                }
                                break;
                               
                            case ".0": // Enable the dot button and change mode and precision
                            case ".00":
                            case "Sci":
                                model.setMode("F");
                                display2.setText("0.0");
                                changeMode(true);
                                model.setPrecision(command);
                                break;
                                
                            case "C": // Reset the calculator
                                display1.setText("");
                                display2.setText("0");
                                changeMode(true);
                                model.reset();
                                break;
                            
                            case "\u00B1":
                            // Check if a number entered is not zero and non empty
                                if(model.getOpcode().length()==0){
                                    if (!model.getOp1().isEmpty() && !model.getOp1().equals("0")) {
                                        //check that there is not already a "-" sign
                                        //to prevent multiple leading "-"
                                        if (model.getOp1().charAt(0) != '-') {
                                            model.setOp1("-" + model.getOp1());
                                            display2.setText(model.getOp1());
                                        } 
                                        else {
                                            model.setOp1(model.getOp1().substring(1));
                                            display2.setText(model.getOp1());
                                        }
                                    }
                                    break;

                                }
                                else{
                                    if (!model.getOp2().isEmpty() && !model.getOp2().equals("0")) {
                                        //check that there is not already a "-" sign
                                        //to prevent multiple leading "-"
                                        if (model.getOp2().charAt(0) != '-') {
                                            model.setOp2("-" + model.getOp2());
                                            display2.setText(model.getOp2());
                                        } 
                                        else {
                                            model.setOp2(model.getOp2().substring(1));
                                            display2.setText(model.getOp2());
                                        }
                                    }
                                    break;
                                }

                            case "Backspace": //Backspace Key
                                if(model.getOpcode().length()==0){
                                    /*checking purpose*/
                                    System.out.println("Hi: " + model.getOp1());
                                    if((model.getOp1().charAt(0) == '-' && model.getOp1().length()>2 ) || (model.getOp1().charAt(0) != '-' && model.getOp1().length()>1 )){
                                        model.setOp1(model.getOp1().substring(0, model.getOp1().length()-1));
                                        display2.setText(model.getOp1());
                                    }
                                    else{
                                        model.setOp1("0.0");
                                        display2.setText(model.getOp1());
                                    }
                                }
                                else{
                                    if((model.getOp2().charAt(0) == '-' && model.getOp2().length()>2 ) || (model.getOp2().charAt(0) != '-' && model.getOp2().length()>1 )){
                                        model.setOp2(model.getOp2().substring(0, model.getOp2().length()-1));
                                        display2.setText(model.getOp2());
                                    }
                                    else{
                                        model.setOp1("0.0");
                                        display2.setText(model.getOp2());
                                    }
                                }
                                break;
                        }
                    }
		} // end of actionPerformed	
	} // end of Controller
} // end of CalculatorViewController class